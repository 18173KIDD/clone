# 外壁塗装の窓口 クローンプロジェクト ドキュメント

## プロジェクト概要

このプロジェクトは「外壁塗装の窓口」（https://gaiheki-madoguchi.com/）のフロントエンドとバックエンドを含む完全な再現を目的としています。Next.jsを使用したフルスタック実装により、修正のしやすい構造を実現しています。

## 技術スタック

- **フロントエンド**: React, Next.js, TypeScript
- **バックエンド**: Next.js API Routes
- **データベース**: MongoDB
- **認証**: NextAuth.js
- **テスト**: Jest, React Testing Library
- **デプロイ**: Vercel

## プロジェクト構造

```
gaiheki-madoguchi-clone/
├── src/
│   ├── components/         # UIコンポーネント
│   │   ├── common/         # 共通コンポーネント（ヘッダー、フッターなど）
│   │   ├── forms/          # フォームコンポーネント
│   │   └── sections/       # セクションコンポーネント
│   ├── hooks/              # カスタムフック
│   ├── lib/                # ユーティリティ関数
│   ├── models/             # データモデルとスキーマ
│   ├── pages/              # ページコンポーネントとAPIルート
│   │   ├── api/            # APIエンドポイント
│   │   └── ...             # 各ページ
│   └── tests/              # テストファイル
├── public/                 # 静的ファイル
├── .env.local              # 環境変数
├── jest.config.js          # Jestの設定
├── package.json            # 依存関係
└── tsconfig.json           # TypeScriptの設定
```

## 主要コンポーネント

### 共通コンポーネント
- **Header.tsx**: サイトのヘッダー
- **Footer.tsx**: サイトのフッター

### フォームコンポーネント
- **DiagnosisForm.tsx**: 相場診断フォーム

### セクションコンポーネント
- **HeroSection.tsx**: ヒーローセクション
- **AboutSection.tsx**: サービス紹介セクション
- **FeaturesSection.tsx**: 特徴紹介セクション
- **AreaSearchSection.tsx**: エリア検索セクション
- **FlowSection.tsx**: 相談の流れセクション
- **FAQSection.tsx**: よくある質問セクション
- **ArticlesSection.tsx**: コラム記事セクション
- **CTASection.tsx**: CTAセクション

## APIエンドポイント

- **/api/diagnosis**: 相場診断フォーム処理
- **/api/clients**: 施工店一覧取得
- **/api/articles**: 記事一覧取得
- **/api/contact**: お問い合わせフォーム処理
- **/api/auth/[...nextauth]**: 認証機能

## データモデル

- **User**: ユーザー情報
- **Client**: 施工店情報
- **Article**: 記事情報
- **Diagnosis**: 相場診断情報
- **Contact**: お問い合わせ情報
- **Review**: レビュー情報

## カスタムフック

- **useDiagnosis.ts**: 相場診断フォームの送信と結果取得
- **useClients.ts**: 施工店データの取得
- **useArticles.ts**: 記事データの取得
- **useContact.ts**: お問い合わせフォームの送信
- **useAuth.ts**: ログイン・ログアウト機能

## テスト

- **api.test.js**: APIルートのテスト
- **hooks.test.js**: カスタムフックのテスト
- **components.test.js**: コンポーネントのテスト
- **e2e.test.js**: E2Eテスト

## セットアップ手順

1. リポジトリをクローン
```bash
git clone <repository-url>
cd gaiheki-madoguchi-clone
```

2. 依存関係をインストール
```bash
npm install
```

3. 環境変数を設定
```
MONGODB_URI=mongodb+srv://your-mongodb-uri
NEXTAUTH_SECRET=your-nextauth-secret
NEXTAUTH_URL=http://localhost:3000
```

4. 開発サーバーを起動
```bash
npm run dev
```

5. テストを実行
```bash
npm test
```

## デプロイ

このプロジェクトはVercelにデプロイすることを想定しています。

1. Vercelアカウントを作成
2. Vercelプロジェクトを作成
3. 環境変数を設定
4. デプロイ

## 修正のしやすさを重視した設計ポイント

1. **コンポーネント分割**: 機能ごとに独立したコンポーネントに分割し、再利用性と保守性を高めています。
2. **TypeScript**: 型安全性により、バグの早期発見と開発効率の向上を実現しています。
3. **カスタムフック**: データ取得ロジックをカスタムフックに分離し、UIとデータ処理の関心を分離しています。
4. **テスト**: 各レイヤー（API、フック、コンポーネント、E2E）でのテストにより、品質を担保しています。
5. **モジュール化**: 機能ごとにファイルを分割し、変更の影響範囲を最小限に抑えています。
6. **ディレクトリ構造**: 論理的なディレクトリ構造により、ファイルの見つけやすさと管理のしやすさを向上させています。
7. **環境変数**: 環境依存の設定を環境変数に分離し、異なる環境での実行を容易にしています。

## 今後の拡張ポイント

1. **管理画面の実装**: 施工店や記事の管理機能
2. **検索機能の強化**: より高度な検索フィルタリング
3. **パフォーマンス最適化**: 画像の最適化、コードの分割
4. **多言語対応**: 国際化対応
5. **アナリティクス**: ユーザー行動の分析機能
