import { FC } from 'react';

interface AreaSearchSectionProps {
  prefectures: Array<{
    name: string;
    slug: string;
  }>;
}

const AreaSearchSection: FC<AreaSearchSectionProps> = ({ prefectures }) => {
  return (
    <section className="p-area-search" id="area-search">
      <div className="p-area-search__container">
        <h2 className="p-area-search__heading">エリアから外壁・屋根塗装の優良業者を探す</h2>
        
        <div className="p-area-search__stats">
          <div className="p-area-search__stat">
            <span className="p-area-search__stat-label">累計利用者数</span>
            <span className="p-area-search__stat-value">60</span>
            <span className="p-area-search__stat-unit">万人</span>
          </div>
          <div className="p-area-search__stat">
            <span className="p-area-search__stat-label">登録施工店</span>
            <span className="p-area-search__stat-value">5,000</span>
            <span className="p-area-search__stat-unit">社以上</span>
          </div>
        </div>
        
        <div className="p-area-search__content">
          <h3 className="p-area-search__subheading">主要エリアから外壁塗装業者を探す</h3>
          <p className="p-area-search__description">お住まいの地域の優良業者をご紹介します</p>
          
          <div className="p-area-search__areas">
            <div className="p-area-search__area-group">
              <h4 className="p-area-search__area-group-title">北海道・東北</h4>
              <ul className="p-area-search__area-list">
                {prefectures
                  .filter(pref => ['hokkaido', 'aomori', 'iwate', 'miyagi', 'akita', 'yamagata', 'fukushima'].includes(pref.slug))
                  .map((pref, index) => (
                    <li className="p-area-search__area-item" key={index}>
                      <a href={`/clients/prefectures/${pref.slug}`} className="p-area-search__area-link">
                        {pref.name}
                      </a>
                    </li>
                  ))
                }
              </ul>
            </div>
            
            <div className="p-area-search__area-group">
              <h4 className="p-area-search__area-group-title">関東</h4>
              <ul className="p-area-search__area-list">
                {prefectures
                  .filter(pref => ['tokyo', 'kanagawa', 'saitama', 'chiba', 'ibaraki', 'tochigi', 'gunma'].includes(pref.slug))
                  .map((pref, index) => (
                    <li className="p-area-search__area-item" key={index}>
                      <a href={`/clients/prefectures/${pref.slug}`} className="p-area-search__area-link">
                        {pref.name}
                      </a>
                    </li>
                  ))
                }
              </ul>
            </div>
            
            <div className="p-area-search__area-group">
              <h4 className="p-area-search__area-group-title">中部</h4>
              <ul className="p-area-search__area-list">
                {prefectures
                  .filter(pref => ['niigata', 'toyama', 'ishikawa', 'fukui', 'yamanashi', 'nagano', 'gifu', 'shizuoka', 'aichi'].includes(pref.slug))
                  .map((pref, index) => (
                    <li className="p-area-search__area-item" key={index}>
                      <a href={`/clients/prefectures/${pref.slug}`} className="p-area-search__area-link">
                        {pref.name}
                      </a>
                    </li>
                  ))
                }
              </ul>
            </div>
            
            <div className="p-area-search__area-group">
              <h4 className="p-area-search__area-group-title">近畿</h4>
              <ul className="p-area-search__area-list">
                {prefectures
                  .filter(pref => ['mie', 'shiga', 'kyoto', 'osaka', 'hyogo', 'nara', 'wakayama'].includes(pref.slug))
                  .map((pref, index) => (
                    <li className="p-area-search__area-item" key={index}>
                      <a href={`/clients/prefectures/${pref.slug}`} className="p-area-search__area-link">
                        {pref.name}
                      </a>
                    </li>
                  ))
                }
              </ul>
            </div>
            
            <div className="p-area-search__area-group">
              <h4 className="p-area-search__area-group-title">中国・四国</h4>
              <ul className="p-area-search__area-list">
                {prefectures
                  .filter(pref => ['tottori', 'shimane', 'okayama', 'hiroshima', 'yamaguchi', 'tokushima', 'kagawa', 'ehime', 'kochi'].includes(pref.slug))
                  .map((pref, index) => (
                    <li className="p-area-search__area-item" key={index}>
                      <a href={`/clients/prefectures/${pref.slug}`} className="p-area-search__area-link">
                        {pref.name}
                      </a>
                    </li>
                  ))
                }
              </ul>
            </div>
            
            <div className="p-area-search__area-group">
              <h4 className="p-area-search__area-group-title">九州・沖縄</h4>
              <ul className="p-area-search__area-list">
                {prefectures
                  .filter(pref => ['fukuoka', 'saga', 'nagasaki', 'kumamoto', 'oita', 'miyazaki', 'kagoshima', 'okinawa'].includes(pref.slug))
                  .map((pref, index) => (
                    <li className="p-area-search__area-item" key={index}>
                      <a href={`/clients/prefectures/${pref.slug}`} className="p-area-search__area-link">
                        {pref.name}
                      </a>
                    </li>
                  ))
                }
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AreaSearchSection;
