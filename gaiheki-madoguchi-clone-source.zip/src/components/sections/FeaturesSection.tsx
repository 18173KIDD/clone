import { FC } from 'react';

const FeaturesSection: FC = () => {
  return (
    <section className="p-features" id="features">
      <div className="p-features__container">
        <h2 className="p-features__heading">
          <span className="p-features__heading-en">Service Features</span>
          <span className="p-features__heading-ja">外壁塗装の窓口の特徴</span>
        </h2>
        
        <div className="p-features__list">
          <div className="p-features__item">
            <div className="p-features__item-number">
              <span className="p-features__item-number-text">Feature</span>
              <span className="p-features__item-number-value">01</span>
            </div>
            <div className="p-features__item-content">
              <div className="p-features__item-image">
                <img src="/images/feature-advisor.jpg" alt="専門の外壁アドバイザー" />
              </div>
              <div className="p-features__item-text">
                <h3 className="p-features__item-title">
                  お客様の悩みを解決する<br />
                  専門の外壁アドバイザーが<br />
                  在籍しています
                </h3>
                <p className="p-features__item-description">
                  経験豊富なアドバイザーにより、<br />
                  契約前のご相談から施工後まで、<br />
                  一貫したサポートを無料で提供します。
                </p>
              </div>
            </div>
          </div>
          
          <div className="p-features__item">
            <div className="p-features__item-number">
              <span className="p-features__item-number-text">Feature</span>
              <span className="p-features__item-number-value">02</span>
            </div>
            <div className="p-features__item-content">
              <div className="p-features__item-image">
                <img src="/images/feature-contractor.jpg" alt="優良施工店" />
              </div>
              <div className="p-features__item-text">
                <h3 className="p-features__item-title">
                  圧倒的な施工実績が<br />
                  あるからこそ、優良施工店<br />
                  をご紹介できます
                </h3>
                <p className="p-features__item-description">
                  外壁塗装の窓口の経験豊富な<br />
                  データベースから、優良施工店のみ<br />
                  厳選してご紹介しています。
                </p>
              </div>
            </div>
            <div className="p-features__item-button">
              <a href="/clients/prefectures" className="p-features__item-button-link">施工店を探す</a>
            </div>
          </div>
          
          <div className="p-features__item">
            <div className="p-features__item-number">
              <span className="p-features__item-number-text">Feature</span>
              <span className="p-features__item-number-value">03</span>
            </div>
            <div className="p-features__item-content">
              <div className="p-features__item-image">
                <img src="/images/feature-estimate.jpg" alt="お見積り比較" />
              </div>
              <div className="p-features__item-text">
                <h3 className="p-features__item-title">
                  お見積りを比較して、<br />
                  お客様に合った<br />
                  施工店を選択できます
                </h3>
                <p className="p-features__item-description">
                  充実の相談サポートと、優良施工店の<br />
                  データベースによりお客様の状況に<br />
                  マッチしたお見積りを提案します。
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
