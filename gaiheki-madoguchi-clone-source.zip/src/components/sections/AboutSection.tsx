import { FC } from 'react';

const AboutSection: FC = () => {
  return (
    <section className="p-about" id="about">
      <div className="p-about__container">
        <h2 className="p-about__heading">
          <span className="p-about__heading-en">About Service</span>
          <span className="p-about__heading-ja">外壁塗装の窓口とは</span>
        </h2>
        
        <p className="p-about__description">
          全国の優良リフォーム会社、塗装専門会社とのネットワークを持ち、<br />
          独立した第三者機関の立場からお客様のご要望やご希望に沿った会社をご案内しています。
        </p>
        
        <div className="p-about__service-flow">
          <div className="p-about__service-item">
            <div className="p-about__service-icon">
              <img src="/images/icon-people.svg" alt="お客様アイコン" />
            </div>
            <h3 className="p-about__service-title">お客様</h3>
            <div className="p-about__service-bubble">
              <p>塗装の相場を知りたい</p>
              <p>見積もりが欲しい</p>
            </div>
          </div>
          
          <div className="p-about__service-center">
            <div className="p-about__service-center-image">
              <img src="/images/service-center.png" alt="外壁塗装の窓口" />
            </div>
            <div className="p-about__service-features">
              <div className="p-about__service-feature">
                <div className="p-about__service-feature-icon">✓</div>
                <p className="p-about__service-feature-text">お客様へ無料の相談サポート</p>
              </div>
              <div className="p-about__service-feature">
                <div className="p-about__service-feature-icon">✓</div>
                <p className="p-about__service-feature-text">優良施工店のご紹介</p>
              </div>
              <div className="p-about__service-feature">
                <div className="p-about__service-feature-icon">✓</div>
                <p className="p-about__service-feature-text">施工店への見積もり依頼</p>
              </div>
            </div>
          </div>
          
          <div className="p-about__service-item">
            <div className="p-about__service-icon">
              <img src="/images/icon-paint.svg" alt="施工店アイコン" />
            </div>
            <h3 className="p-about__service-title">優良施工店</h3>
          </div>
        </div>
        
        <p className="p-about__quality-message">
          高品質のリフォームを適正価格でご提供します
        </p>
      </div>
    </section>
  );
};

export default AboutSection;
