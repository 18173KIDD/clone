import { FC } from 'react';

const FlowSection: FC = () => {
  return (
    <section className="p-flow" id="flow">
      <div className="p-flow__container">
        <h2 className="p-flow__heading">ご相談の流れ</h2>
        <p className="p-flow__subheading">外壁塗装の窓口のご相談の流れをご説明します</p>
        
        <div className="p-flow__steps">
          <div className="p-flow__step">
            <div className="p-flow__step-number">1</div>
            <h3 className="p-flow__step-title">
              お建物のご状況を<br />
              お知らせください
            </h3>
            <p className="p-flow__step-description">
              ご希望の施工箇所や現在お困りのご状況を、本ページ内にある「外壁塗装の相場を診断」のフームよりご入力ください。およそ10秒で簡単に入力できます。
            </p>
          </div>
          
          <div className="p-flow__step">
            <div className="p-flow__step-number">2</div>
            <h3 className="p-flow__step-title">
              専門の外壁アドバイザーが<br />
              お電話にてご相談を承ります
            </h3>
            <p className="p-flow__step-description">
              ご入力いただいた内容を元に、お客様のご状況を詳しくヒアリングさせていただきます。不安要素やお悩み、ご質問等なんでもお伺いいたします。
            </p>
          </div>
          
          <div className="p-flow__step">
            <div className="p-flow__step-number">3</div>
            <h3 className="p-flow__step-title">
              ご要望に沿った施工店を<br />
              ご紹介いたします
            </h3>
            <p className="p-flow__step-description">
              "外壁塗装の窓口"の厳しい審査をクリアした優良施工店のうちご要望に沿った施工店をご紹介し、お見積りを取得することができます。
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FlowSection;
