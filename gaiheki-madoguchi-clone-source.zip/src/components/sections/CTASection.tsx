import { FC } from 'react';

const CTASection: FC = () => {
  return (
    <section className="p-cta" id="cta">
      <div className="p-cta__container">
        <div className="p-cta__content">
          <h2 className="p-cta__heading">
            あなたの家の外壁塗装<br />
            今すぐ無料で相談する
          </h2>
          
          <div className="p-cta__buttons">
            <a href="#diagnosis-form" className="p-cta__button p-cta__button--primary">
              <span className="p-cta__button-text">相場を診断する</span>
            </a>
            <a href="tel:0120-945-990" className="p-cta__button p-cta__button--secondary">
              <span className="p-cta__button-icon">
                <img src="/images/tel-pc.svg" alt="電話アイコン" />
              </span>
              <span className="p-cta__button-text">
                <span className="p-cta__button-number">0120-945-990</span>
                <span className="p-cta__button-time">24時間受付中（年中無休）</span>
              </span>
            </a>
          </div>
          
          <div className="p-cta__benefits">
            <div className="p-cta__benefit">
              <div className="p-cta__benefit-icon">✓</div>
              <p className="p-cta__benefit-text">相場診断でAmazonギフト券1,000円分プレゼント</p>
            </div>
            <div className="p-cta__benefit">
              <div className="p-cta__benefit-icon">✓</div>
              <p className="p-cta__benefit-text">外壁塗装の専門アドバイザーが無料でサポート</p>
            </div>
            <div className="p-cta__benefit">
              <div className="p-cta__benefit-icon">✓</div>
              <p className="p-cta__benefit-text">厳選された優良施工店のみをご紹介</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
