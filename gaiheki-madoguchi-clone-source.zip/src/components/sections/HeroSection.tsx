import { FC } from 'react';

interface HeroSectionProps {
  onConsultClick: () => void;
}

const HeroSection: FC<HeroSectionProps> = ({ onConsultClick }) => {
  return (
    <section className="p-hero">
      <div className="p-hero__container">
        <div className="p-hero__content">
          <div className="p-hero__text-area">
            <h1 className="p-hero__title">
              <span className="p-hero__title-line">おうちの塗装</span>
              <span className="p-hero__title-line">はもう悩まない。</span>
            </h1>
            
            <div className="p-hero__stats">
              <div className="p-hero__stat">
                <span className="p-hero__stat-label">累計利用者数</span>
                <span className="p-hero__stat-value">60<span className="p-hero__stat-unit">万人</span></span>
              </div>
              <div className="p-hero__stat">
                <span className="p-hero__stat-label">登録施工店</span>
                <span className="p-hero__stat-value">5,000<span className="p-hero__stat-unit">社以上</span></span>
              </div>
            </div>
            
            <div className="p-hero__badges">
              <div className="p-hero__badge">
                <p className="p-hero__badge-text">適正相場がわかる<br />外壁塗装無料相談サイト</p>
                <div className="p-hero__badge-rank">No.1</div>
              </div>
              <div className="p-hero__badge">
                <p className="p-hero__badge-text">優良施工店と出会える<br />外壁塗装無料相談サイト</p>
                <div className="p-hero__badge-rank">No.1</div>
              </div>
              <div className="p-hero__badge">
                <p className="p-hero__badge-text">担当者が信頼できる<br />外壁塗装無料相談サイト</p>
                <div className="p-hero__badge-rank">No.1</div>
              </div>
            </div>
            
            <p className="p-hero__research-note">
              日本マーケティングリサーチ機構調べ 調査概要:2021年1月期ブランドのイメージ調査
            </p>
          </div>
          
          <div className="p-hero__image-area">
            <div className="p-hero__house-image">
              <img src="/images/mv_house.png" alt="家のイラスト" />
              <div className="p-hero__color-selector">
                <div className="p-hero__color-label">Select Color</div>
                <div className="p-hero__color-options">
                  <button className="p-hero__color-option p-hero__color-option--blue active"></button>
                  <button className="p-hero__color-option p-hero__color-option--orange"></button>
                  <button className="p-hero__color-option p-hero__color-option--green"></button>
                  <button className="p-hero__color-option p-hero__color-option--red"></button>
                  <button className="p-hero__color-option p-hero__color-option--purple"></button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <button className="p-hero__consult-button" onClick={onConsultClick}>
          今すぐ相談する
        </button>
      </div>
    </section>
  );
};

export default HeroSection;
