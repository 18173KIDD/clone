import { FC } from 'react';

interface FAQSectionProps {
  faqs: Array<{
    question: string;
    answer: string;
  }>;
}

const FAQSection: FC<FAQSectionProps> = ({ faqs }) => {
  return (
    <section className="p-faq" id="faq">
      <div className="p-faq__container">
        <h2 className="p-faq__heading">よくある質問</h2>
        <p className="p-faq__subheading">外壁塗装の窓口のよくある質問についてお答えします</p>
        
        <div className="p-faq__list">
          {faqs.map((faq, index) => (
            <div className="p-faq__item" key={index}>
              <div className="p-faq__question">
                <span className="p-faq__question-icon">Q</span>
                <h3 className="p-faq__question-text">{faq.question}</h3>
                <div className="p-faq__toggle-icon">
                  <span></span>
                  <span></span>
                </div>
              </div>
              <div className="p-faq__answer">
                <div className="p-faq__answer-icon">A</div>
                <div className="p-faq__answer-text" dangerouslySetInnerHTML={{ __html: faq.answer }}></div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="p-faq__video">
          <h3 className="p-faq__video-heading">
            <span className="p-faq__video-heading-en">Promotion Video</span>
            <span className="p-faq__video-heading-ja">動画でみる外壁塗装の窓口</span>
          </h3>
          <p className="p-faq__video-description">
            外壁塗装の窓口の特徴を動画でわかりやすくご紹介します。<br />
            （再生時間：2分04秒）
          </p>
          <div className="p-faq__video-container">
            <iframe 
              className="p-faq__video-iframe"
              src="https://www.youtube.com/embed/YOUTUBE_VIDEO_ID" 
              title="外壁塗装の窓口紹介動画"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
