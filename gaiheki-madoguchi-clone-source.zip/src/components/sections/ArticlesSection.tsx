import { FC } from 'react';

interface ArticlesSectionProps {
  articles: Array<{
    id: string;
    title: string;
    slug: string;
    imageUrl: string;
    category: string;
  }>;
}

const ArticlesSection: FC<ArticlesSectionProps> = ({ articles }) => {
  return (
    <section className="p-articles" id="articles">
      <div className="p-articles__container">
        <h2 className="p-articles__heading">外壁・屋根塗装の関連コラム</h2>
        <p className="p-articles__subheading">外壁塗装のコラムを紹介します</p>
        
        <div className="p-articles__categories">
          <h3 className="p-articles__category-title">外壁塗装の助成金に関連するコラム</h3>
          <div className="p-articles__list">
            {articles
              .filter(article => article.category === 'subsidy')
              .slice(0, 7)
              .map((article, index) => (
                <a href={`/articles/${article.slug}`} className="p-articles__item" key={index}>
                  <div className="p-articles__item-image">
                    <img src={article.imageUrl} alt={article.title} />
                  </div>
                  <h4 className="p-articles__item-title">{article.title}</h4>
                </a>
              ))
            }
          </div>
          
          <h3 className="p-articles__category-title">外壁塗装の相場に関連するコラム</h3>
          <div className="p-articles__list">
            {articles
              .filter(article => article.category === 'price')
              .slice(0, 8)
              .map((article, index) => (
                <a href={`/articles/${article.slug}`} className="p-articles__item" key={index}>
                  <div className="p-articles__item-image">
                    <img src={article.imageUrl} alt={article.title} />
                  </div>
                  <h4 className="p-articles__item-title">{article.title}</h4>
                </a>
              ))
            }
          </div>
          
          <h3 className="p-articles__category-title">外壁塗装を安くする方法に関連するコラム</h3>
          <div className="p-articles__list">
            {articles
              .filter(article => article.category === 'cost-saving')
              .slice(0, 4)
              .map((article, index) => (
                <a href={`/articles/${article.slug}`} className="p-articles__item" key={index}>
                  <div className="p-articles__item-image">
                    <img src={article.imageUrl} alt={article.title} />
                  </div>
                  <h4 className="p-articles__item-title">{article.title}</h4>
                </a>
              ))
            }
          </div>
          
          <h3 className="p-articles__category-title">外壁塗装の塗料に関連するコラム</h3>
          <div className="p-articles__list">
            {articles
              .filter(article => article.category === 'paint')
              .slice(0, 2)
              .map((article, index) => (
                <a href={`/articles/${article.slug}`} className="p-articles__item" key={index}>
                  <div className="p-articles__item-image">
                    <img src={article.imageUrl} alt={article.title} />
                  </div>
                  <h4 className="p-articles__item-title">{article.title}</h4>
                </a>
              ))
            }
          </div>
          
          <h3 className="p-articles__category-title">外壁・屋根の工法に関連するコラム</h3>
          <div className="p-articles__list">
            {articles
              .filter(article => article.category === 'method')
              .slice(0, 2)
              .map((article, index) => (
                <a href={`/articles/${article.slug}`} className="p-articles__item" key={index}>
                  <div className="p-articles__item-image">
                    <img src={article.imageUrl} alt={article.title} />
                  </div>
                  <h4 className="p-articles__item-title">{article.title}</h4>
                </a>
              ))
            }
          </div>
        </div>
        
        <div className="p-articles__more">
          <a href="/articles" className="p-articles__more-link">外壁・屋根塗装コラム一覧</a>
        </div>
      </div>
    </section>
  );
};

export default ArticlesSection;
