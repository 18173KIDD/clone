import { FC } from 'react';

interface DiagnosisFormProps {
  onSubmit: (data: DiagnosisFormData) => void;
}

export interface DiagnosisFormData {
  prefecture: string;
  area: string;
  situation: string;
  workType: string;
  phone: string;
  email?: string;
}

const DiagnosisForm: FC<DiagnosisFormProps> = ({ onSubmit }) => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const formData = new FormData(e.currentTarget);
    const data: DiagnosisFormData = {
      prefecture: formData.get('prefecture') as string,
      area: formData.get('area') as string,
      situation: formData.get('situation') as string,
      workType: formData.get('workType') as string,
      phone: formData.get('phone') as string,
      email: formData.get('email') as string || undefined,
    };
    
    onSubmit(data);
  };

  return (
    <div className="p-diagnosis-form">
      <div className="p-diagnosis-form__container">
        <h2 className="p-diagnosis-form__title">外壁塗装の相場を診断</h2>
        <div className="p-diagnosis-form__content">
          <div className="p-diagnosis-form__gift">
            <div className="p-diagnosis-form__gift-image">
              <img src="/images/amazon-gift.png" alt="Amazonギフト券" />
            </div>
            <div className="p-diagnosis-form__gift-text">
              <p>相場診断でAmazonギフト券</p>
              <p className="p-diagnosis-form__gift-amount">1000円分</p>
              <p>プレゼント中！</p>
            </div>
          </div>
          
          <form className="p-diagnosis-form__form" onSubmit={handleSubmit}>
            <div className="p-diagnosis-form__form-group">
              <label className="p-diagnosis-form__label">
                都道府県
                <span className="p-diagnosis-form__required">必須</span>
              </label>
              <select name="prefecture" className="p-diagnosis-form__select" required>
                <option value="">選択してください</option>
                <option value="hokkaido">北海道</option>
                <option value="aomori">青森県</option>
                {/* 他の都道府県オプション */}
              </select>
            </div>
            
            <div className="p-diagnosis-form__form-group">
              <label className="p-diagnosis-form__label">
                延面積
                <span className="p-diagnosis-form__required">必須</span>
              </label>
              <select name="area" className="p-diagnosis-form__select" required>
                <option value="">選択してください</option>
                <option value="unknown">わからない</option>
                <option value="under50">～50 平米</option>
                <option value="50to100">50～100 平米</option>
                <option value="100to150">100～150 平米</option>
                <option value="over150">150 平米～</option>
              </select>
            </div>
            
            <div className="p-diagnosis-form__form-group">
              <label className="p-diagnosis-form__label">
                現在の状況
                <span className="p-diagnosis-form__required">必須</span>
              </label>
              <select name="situation" className="p-diagnosis-form__select" required>
                <option value="">選択してください</option>
                <option value="price">価格の相場が気になる</option>
                <option value="damage">外壁や屋根の傷みが気になる</option>
                <option value="quote">見積もりを取りたい</option>
                <option value="consultation">相談したい</option>
              </select>
            </div>
            
            <div className="p-diagnosis-form__form-group">
              <label className="p-diagnosis-form__label">
                工事箇所
                <span className="p-diagnosis-form__required">必須</span>
              </label>
              <select name="workType" className="p-diagnosis-form__select" required>
                <option value="">選択してください</option>
                <option value="wall">外壁の塗装</option>
                <option value="roof">屋根の塗装</option>
                <option value="both">外壁と屋根の塗装</option>
                <option value="other">その他</option>
              </select>
            </div>
            
            <div className="p-diagnosis-form__form-group">
              <label className="p-diagnosis-form__label">
                携帯電話番号
                <span className="p-diagnosis-form__required">必須</span>
              </label>
              <input 
                type="tel" 
                name="phone" 
                className="p-diagnosis-form__input" 
                placeholder="例: 08012345678" 
                pattern="[0-9]{10,11}" 
                required 
              />
              <p className="p-diagnosis-form__note">
                ※こちらの携帯電話番号宛にSMSメール形式で相場診断結果と小冊子のダウンロードリンクをお送りしますので、お間違えのないようにご入力ください。
              </p>
            </div>
            
            <div className="p-diagnosis-form__form-group">
              <label className="p-diagnosis-form__label">
                メールアドレス
                <span className="p-diagnosis-form__optional">任意</span>
              </label>
              <input 
                type="email" 
                name="email" 
                className="p-diagnosis-form__input" 
                placeholder="例: example@example.com" 
              />
            </div>
            
            <div className="p-diagnosis-form__agreement">
              <p>
                <a href="/terms" className="p-diagnosis-form__link">利用規約</a>と
                <a href="/privacy-policy" className="p-diagnosis-form__link">プライバシーポリシー</a>に同意して、
              </p>
            </div>
            
            <button type="submit" className="p-diagnosis-form__submit">
              <span className="p-diagnosis-form__submit-free">無料</span>
              今すぐ相場を診断する
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default DiagnosisForm;
