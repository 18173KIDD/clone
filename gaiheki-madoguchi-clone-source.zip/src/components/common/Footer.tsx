import { FC } from 'react';

const Footer: FC = () => {
  return (
    <footer className="l-footer">
      <div className="p-footer">
        <div className="p-footer__container">
          <div className="p-footer__logo">
            <a href="/" className="p-footer__logo_link">
              <img src="/images/logo.svg" alt="外壁塗装の窓口" className="p-footer__logo_image" />
            </a>
          </div>
          <div className="p-footer__nav">
            <ul className="p-footer__nav_list">
              <li className="p-footer__nav_item">
                <a href="/clients/prefectures" className="p-footer__nav_link">施工店一覧</a>
              </li>
              <li className="p-footer__nav_item">
                <a href="/articles" className="p-footer__nav_link">外壁塗装コラム</a>
              </li>
              <li className="p-footer__nav_item">
                <a href="/articles/subsidy" className="p-footer__nav_link">外壁塗装助成金</a>
              </li>
              <li className="p-footer__nav_item">
                <a href="/articles/price" className="p-footer__nav_link">外壁塗装相場</a>
              </li>
              <li className="p-footer__nav_item">
                <a href="/ads" className="p-footer__nav_link">加盟店募集</a>
              </li>
              <li className="p-footer__nav_item">
                <a href="/contact" className="p-footer__nav_link">お問い合わせ</a>
              </li>
              <li className="p-footer__nav_item">
                <a href="/privacy-policy" className="p-footer__nav_link">プライバシーポリシー</a>
              </li>
              <li className="p-footer__nav_item">
                <a href="/terms" className="p-footer__nav_link">利用規約</a>
              </li>
            </ul>
          </div>
          <div className="p-footer__copyright">
            <p className="p-footer__copyright_text">© 外壁塗装の窓口 All Rights Reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
