import { FC } from 'react';
import Link from 'next/link';

const Header: FC = () => {
  return (
    <header className="l-header">
      <div className="l-header__wrapper">
        <div className="l-header__overlay"></div>
        <div className="p-header">
          <div className="p-header__container">
            <div className="p-header__logo">
              <Link href="/" className="p-header__logo_link">
                <div className="p-header__logo_link_wrapper">
                  <img src="/images/logo.svg" alt="外壁塗装の窓口" className="p-header__logo_image" />
                </div>
              </Link>
            </div>
            <div className="p-header__nav_upper">
              <div className="p-header__tel">
                <div className="p-header__tel_wrapper">
                  <img src="/images/tel-pc.svg" alt="" className="pc-only p-header__tel_icon" />
                  <div className="p-header__tel_text pc-only">
                    <span className="tel-number">0120-945-990</span>
                    <span className="tel-time">24時間受付中（年中無休）</span>
                  </div>
                </div>
              </div>
              <div className="p-header__contact_button p-header__button">
                <Link href="/contact" className="p-header__button_link">
                  <div className="p-header__button_wrapper">
                    <span className="p-header__button_link_text">お問い合わせ</span>
                  </div>
                </Link>
              </div>
            </div>
            <nav className="p-header__nav">
              <div className="p-header__nav_item_list_disappearable_container">
                <ul className="p-header__nav_item_list">
                  <li className="p-header__nav_item">
                    <Link href="/clients/prefectures" className="p-header__nav_item_link">
                      <div className="p-header__nav_item_wrapper">
                        <span className="p-header__nav_item_text">施工店一覧</span>
                      </div>
                    </Link>
                  </li>
                  <li className="p-header__nav_item">
                    <Link href="/articles" className="p-header__nav_item_link">
                      <div className="p-header__nav_item_wrapper">
                        <span className="p-header__nav_item_text">外壁塗装コラム</span>
                      </div>
                    </Link>
                  </li>
                  <li className="p-header__nav_item">
                    <Link href="/articles/subsidy" className="p-header__nav_item_link">
                      <div className="p-header__nav_item_wrapper">
                        <span className="p-header__nav_item_text">外壁塗装助成金</span>
                      </div>
                    </Link>
                  </li>
                  <li className="p-header__nav_item">
                    <Link href="/articles/price" className="p-header__nav_item_link">
                      <div className="p-header__nav_item_wrapper">
                        <span className="p-header__nav_item_text">外壁塗装相場</span>
                      </div>
                    </Link>
                  </li>
                  <li className="p-header__nav_item">
                    <Link href="/ads" className="p-header__nav_item_link">
                      <div className="p-header__nav_item_wrapper">
                        <span className="p-header__nav_item_text">加盟店募集</span>
                      </div>
                    </Link>
                  </li>
                </ul>
              </div>
            </nav>
            <div className="p-header__hamburger_menu_container">
              <div className="p-header__hamburger_menu_button">
                <span></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
