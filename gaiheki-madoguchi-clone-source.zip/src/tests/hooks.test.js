// src/tests/hooks.test.js
import { describe, it, expect, beforeEach, afterEach, jest } from '@jest/globals';
import { renderHook, act } from '@testing-library/react-hooks';
import { useDiagnosis } from '../hooks/useDiagnosis';
import { useClients } from '../hooks/useClients';
import { useArticles } from '../hooks/useArticles';
import { useContact } from '../hooks/useContact';

// フェッチのモック
global.fetch = jest.fn();

describe('Custom Hooks', () => {
  beforeEach(() => {
    fetch.mockClear();
  });

  describe('useDiagnosis', () => {
    it('診断フォームを送信し、結果を返す', async () => {
      const mockResponse = {
        success: true,
        message: '相場診断フォームが送信されました',
        result: {
          estimatedPrice: {
            min: 600000,
            max: 900000
          },
          recommendedPaint: 'シリコン塗料',
          estimatedDuration: '2週間〜3週間',
          nextStep: 'アドバイザーからお電話でご連絡いたします'
        }
      };

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse
      });

      const { result } = renderHook(() => useDiagnosis());

      await act(async () => {
        await result.current.submitDiagnosis({
          prefecture: 'tokyo',
          area: '100to150',
          situation: 'price',
          workType: 'wall',
          phone: '08012345678'
        });
      });

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBeNull();
      expect(result.current.result).toEqual(mockResponse.result);
      expect(fetch).toHaveBeenCalledTimes(1);
      expect(fetch).toHaveBeenCalledWith('/api/diagnosis', expect.any(Object));
    });

    it('エラーが発生した場合はエラーメッセージを設定する', async () => {
      const errorMessage = '相場診断の送信に失敗しました';
      fetch.mockResolvedValueOnce({
        ok: false,
        json: async () => ({ message: errorMessage })
      });

      const { result } = renderHook(() => useDiagnosis());

      await act(async () => {
        await result.current.submitDiagnosis({
          prefecture: 'tokyo',
          area: '100to150',
          situation: 'price',
          workType: 'wall',
          phone: '08012345678'
        });
      });

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBe(errorMessage);
      expect(result.current.result).toBeNull();
    });
  });

  describe('useClients', () => {
    it('施工店一覧を取得する', async () => {
      const mockClients = [
        {
          id: '1',
          name: '株式会社外壁塗装プロ',
          prefecture: 'tokyo'
        },
        {
          id: '2',
          name: '株式会社匠塗装',
          prefecture: 'osaka'
        }
      ];

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, clients: mockClients })
      });

      const { result, waitForNextUpdate } = renderHook(() => useClients());
      
      await waitForNextUpdate();

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBeNull();
      expect(result.current.clients).toEqual(mockClients);
      expect(fetch).toHaveBeenCalledTimes(1);
      expect(fetch).toHaveBeenCalledWith('/api/clients');
    });

    it('都道府県でフィルタリングされた施工店一覧を取得する', async () => {
      const mockClients = [
        {
          id: '1',
          name: '株式会社外壁塗装プロ',
          prefecture: 'tokyo'
        }
      ];

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, clients: mockClients })
      });

      const { result, waitForNextUpdate } = renderHook(() => useClients('tokyo'));
      
      await waitForNextUpdate();

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBeNull();
      expect(result.current.clients).toEqual(mockClients);
      expect(fetch).toHaveBeenCalledTimes(1);
      expect(fetch).toHaveBeenCalledWith('/api/clients?prefecture=tokyo');
    });
  });

  describe('useArticles', () => {
    it('記事一覧を取得する', async () => {
      const mockArticles = [
        {
          id: '1',
          title: '記事1',
          category: 'subsidy'
        },
        {
          id: '2',
          title: '記事2',
          category: 'price'
        }
      ];

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, articles: mockArticles })
      });

      const { result, waitForNextUpdate } = renderHook(() => useArticles());
      
      await waitForNextUpdate();

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBeNull();
      expect(result.current.articles).toEqual(mockArticles);
      expect(fetch).toHaveBeenCalledTimes(1);
      expect(fetch).toHaveBeenCalledWith('/api/articles');
    });

    it('カテゴリでフィルタリングされた記事一覧を取得する', async () => {
      const mockArticles = [
        {
          id: '1',
          title: '記事1',
          category: 'subsidy'
        }
      ];

      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, articles: mockArticles })
      });

      const { result, waitForNextUpdate } = renderHook(() => useArticles('subsidy'));
      
      await waitForNextUpdate();

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBeNull();
      expect(result.current.articles).toEqual(mockArticles);
      expect(fetch).toHaveBeenCalledTimes(1);
      expect(fetch).toHaveBeenCalledWith('/api/articles?category=subsidy');
    });
  });

  describe('useContact', () => {
    it('お問い合わせフォームを送信する', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => ({ success: true, message: 'お問い合わせが送信されました' })
      });

      const { result } = renderHook(() => useContact());

      await act(async () => {
        await result.current.submitContact({
          name: 'テスト太郎',
          email: 'test@example.com',
          message: 'これはテストメッセージです。'
        });
      });

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBeNull();
      expect(result.current.success).toBe(true);
      expect(fetch).toHaveBeenCalledTimes(1);
      expect(fetch).toHaveBeenCalledWith('/api/contact', expect.any(Object));
    });

    it('エラーが発生した場合はエラーメッセージを設定する', async () => {
      const errorMessage = 'お問い合わせの送信に失敗しました';
      fetch.mockResolvedValueOnce({
        ok: false,
        json: async () => ({ message: errorMessage })
      });

      const { result } = renderHook(() => useContact());

      await act(async () => {
        await result.current.submitContact({
          name: 'テスト太郎',
          email: 'test@example.com',
          message: 'これはテストメッセージです。'
        });
      });

      expect(result.current.loading).toBe(false);
      expect(result.current.error).toBe(errorMessage);
      expect(result.current.success).toBe(false);
    });
  });
});
