// src/tests/e2e.test.js
import { describe, it, expect, beforeAll, afterAll, jest } from '@jest/globals';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import HomePage from '../pages/index';
import { SessionProvider } from 'next-auth/react';

// MSWサーバーのセットアップ
const server = setupServer(
  // 相場診断APIのモック
  rest.post('/api/diagnosis', (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        message: '相場診断フォームが送信されました',
        result: {
          estimatedPrice: {
            min: 600000,
            max: 900000
          },
          recommendedPaint: 'シリコン塗料',
          estimatedDuration: '2週間〜3週間',
          nextStep: 'アドバイザーからお電話でご連絡いたします'
        }
      })
    );
  }),
  
  // 施工店一覧APIのモック
  rest.get('/api/clients', (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        clients: [
          {
            id: '1',
            name: '株式会社外壁塗装プロ',
            prefecture: 'tokyo'
          },
          {
            id: '2',
            name: '株式会社匠塗装',
            prefecture: 'osaka'
          }
        ]
      })
    );
  }),
  
  // 記事一覧APIのモック
  rest.get('/api/articles', (req, res, ctx) => {
    return res(
      ctx.json({
        success: true,
        articles: [
          {
            id: '1',
            title: '記事1',
            slug: 'article1',
            imageUrl: '/images/article-sample.jpg',
            category: 'subsidy'
          },
          {
            id: '2',
            title: '記事2',
            slug: 'article2',
            imageUrl: '/images/article-sample.jpg',
            category: 'price'
          }
        ]
      })
    );
  })
);

// テスト開始前にサーバーを起動
beforeAll(() => server.listen());
// 各テスト後にリクエストハンドラーをリセット
afterEach(() => server.resetHandlers());
// テスト終了後にサーバーをクローズ
afterAll(() => server.close());

// モックセッション
const mockSession = {
  expires: new Date(Date.now() + 2 * 86400).toISOString(),
  user: { name: "テストユーザー", email: "test@example.com" }
};

describe('E2Eテスト', () => {
  it('ホームページが正しくレンダリングされ、相場診断フォームが機能する', async () => {
    // ホームページをレンダリング
    render(
      <SessionProvider session={mockSession}>
        <HomePage />
      </SessionProvider>
    );
    
    // ページのタイトルが表示されることを確認
    expect(screen.getByText('おうちの塗装')).toBeInTheDocument();
    expect(screen.getByText('はもう悩まない。')).toBeInTheDocument();
    
    // 相場診断フォームが表示されることを確認
    expect(screen.getByText('外壁塗装の相場を診断')).toBeInTheDocument();
    
    // フォームに値を入力
    fireEvent.change(screen.getByLabelText(/都道府県/), { target: { value: 'tokyo' } });
    fireEvent.change(screen.getByLabelText(/延面積/), { target: { value: '100to150' } });
    fireEvent.change(screen.getByLabelText(/現在の状況/), { target: { value: 'price' } });
    fireEvent.change(screen.getByLabelText(/工事箇所/), { target: { value: 'wall' } });
    fireEvent.change(screen.getByLabelText(/携帯電話番号/), { target: { value: '08012345678' } });
    
    // フォームを送信
    fireEvent.click(screen.getByText('今すぐ相場を診断する'));
    
    // 送信後の処理を確認（モックレスポンスにより成功するはず）
    await waitFor(() => {
      // 成功メッセージまたは次のステップが表示されることを確認
      // 注: 実際の実装によって確認方法は異なる場合があります
      expect(screen.getByText(/相場診断フォームが送信されました/)).toBeInTheDocument();
    });
  });

  it('「今すぐ相談する」ボタンをクリックすると相場診断フォームにスクロールする', () => {
    // ホームページをレンダリング
    render(
      <SessionProvider session={mockSession}>
        <HomePage />
      </SessionProvider>
    );
    
    // スクロールのモック
    const scrollIntoViewMock = jest.fn();
    Element.prototype.scrollIntoView = scrollIntoViewMock;
    
    // 「今すぐ相談する」ボタンをクリック
    fireEvent.click(screen.getByText('今すぐ相談する'));
    
    // scrollIntoViewが呼ばれることを確認
    expect(scrollIntoViewMock).toHaveBeenCalledTimes(1);
  });
});
