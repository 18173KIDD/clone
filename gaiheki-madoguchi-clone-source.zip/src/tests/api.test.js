// src/tests/api.test.js
import { describe, it, expect, beforeAll, afterAll, jest } from '@jest/globals';
import { createMocks } from 'node-mocks-http';
import diagnosisHandler from '../pages/api/diagnosis';
import clientsHandler from '../pages/api/clients/index';
import articlesHandler from '../pages/api/articles/index';
import contactHandler from '../pages/api/contact';

// モックデータ
const mockDiagnosisData = {
  prefecture: 'tokyo',
  area: '100to150',
  situation: 'price',
  workType: 'wall',
  phone: '08012345678',
  email: 'test@example.com'
};

const mockContactData = {
  name: 'テスト太郎',
  email: 'test@example.com',
  phone: '08012345678',
  message: 'これはテストメッセージです。'
};

// MongoDB接続をモック化
jest.mock('../lib/dbConnect', () => {
  return jest.fn().mockImplementation(() => {
    return Promise.resolve();
  });
});

describe('API Routes', () => {
  describe('/api/diagnosis', () => {
    it('POSTリクエストを処理し、相場診断結果を返す', async () => {
      const { req, res } = createMocks({
        method: 'POST',
        body: mockDiagnosisData,
      });

      await diagnosisHandler(req, res);

      expect(res._getStatusCode()).toBe(200);
      expect(JSON.parse(res._getData())).toHaveProperty('success', true);
      expect(JSON.parse(res._getData())).toHaveProperty('result');
    });

    it('必須フィールドが欠けている場合はエラーを返す', async () => {
      const { req, res } = createMocks({
        method: 'POST',
        body: { prefecture: 'tokyo' }, // 必須フィールドが不足
      });

      await diagnosisHandler(req, res);

      expect(res._getStatusCode()).toBe(400);
    });
  });

  describe('/api/clients', () => {
    it('GETリクエストを処理し、施工店一覧を返す', async () => {
      const { req, res } = createMocks({
        method: 'GET',
      });

      await clientsHandler(req, res);

      expect(res._getStatusCode()).toBe(200);
      expect(JSON.parse(res._getData())).toHaveProperty('success', true);
      expect(JSON.parse(res._getData())).toHaveProperty('clients');
    });

    it('都道府県でフィルタリングされた施工店一覧を返す', async () => {
      const { req, res } = createMocks({
        method: 'GET',
        query: { prefecture: 'tokyo' },
      });

      await clientsHandler(req, res);

      expect(res._getStatusCode()).toBe(200);
      const data = JSON.parse(res._getData());
      expect(data).toHaveProperty('success', true);
      expect(data).toHaveProperty('clients');
      // 東京の施工店のみが含まれていることを確認
      data.clients.forEach(client => {
        expect(client.prefecture).toBe('tokyo');
      });
    });
  });

  describe('/api/articles', () => {
    it('GETリクエストを処理し、記事一覧を返す', async () => {
      const { req, res } = createMocks({
        method: 'GET',
      });

      await articlesHandler(req, res);

      expect(res._getStatusCode()).toBe(200);
      expect(JSON.parse(res._getData())).toHaveProperty('success', true);
      expect(JSON.parse(res._getData())).toHaveProperty('articles');
    });

    it('カテゴリでフィルタリングされた記事一覧を返す', async () => {
      const { req, res } = createMocks({
        method: 'GET',
        query: { category: 'subsidy' },
      });

      await articlesHandler(req, res);

      expect(res._getStatusCode()).toBe(200);
      const data = JSON.parse(res._getData());
      expect(data).toHaveProperty('success', true);
      expect(data).toHaveProperty('articles');
      // 助成金カテゴリの記事のみが含まれていることを確認
      data.articles.forEach(article => {
        expect(article.category).toBe('subsidy');
      });
    });
  });

  describe('/api/contact', () => {
    it('POSTリクエストを処理し、お問い合わせを送信する', async () => {
      const { req, res } = createMocks({
        method: 'POST',
        body: mockContactData,
      });

      await contactHandler(req, res);

      expect(res._getStatusCode()).toBe(200);
      expect(JSON.parse(res._getData())).toHaveProperty('success', true);
    });

    it('必須フィールドが欠けている場合はエラーを返す', async () => {
      const { req, res } = createMocks({
        method: 'POST',
        body: { name: 'テスト太郎' }, // 必須フィールドが不足
      });

      await contactHandler(req, res);

      expect(res._getStatusCode()).toBe(400);
    });
  });
});
