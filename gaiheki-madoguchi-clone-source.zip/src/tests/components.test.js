// src/tests/components.test.js
import { describe, it, expect, jest } from '@jest/globals';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import DiagnosisForm from '../components/forms/DiagnosisForm';
import HeroSection from '../components/sections/HeroSection';
import FAQSection from '../components/sections/FAQSection';

// モックデータ
const mockFaqs = [
  {
    question: '外壁塗装の窓口を利用するのに費用はかかりますか？',
    answer: '外壁塗装の窓口のご利用は<strong>完全無料</strong>です。相談料や紹介料などの費用は一切かかりません。'
  },
  {
    question: '外壁塗装の相場はどのくらいですか？',
    answer: '一般的な戸建て住宅（30坪程度）の外壁塗装の相場は、60〜90万円程度です。'
  }
];

describe('Components', () => {
  describe('DiagnosisForm', () => {
    it('フォームが正しくレンダリングされる', () => {
      const mockSubmit = jest.fn();
      render(<DiagnosisForm onSubmit={mockSubmit} />);
      
      expect(screen.getByText('外壁塗装の相場を診断')).toBeInTheDocument();
      expect(screen.getByText('都道府県')).toBeInTheDocument();
      expect(screen.getByText('延面積')).toBeInTheDocument();
      expect(screen.getByText('現在の状況')).toBeInTheDocument();
      expect(screen.getByText('工事箇所')).toBeInTheDocument();
      expect(screen.getByText('携帯電話番号')).toBeInTheDocument();
    });

    it('フォーム送信時にonSubmitが呼ばれる', async () => {
      const mockSubmit = jest.fn();
      render(<DiagnosisForm onSubmit={mockSubmit} />);
      
      // フォームに値を入力
      fireEvent.change(screen.getByLabelText(/都道府県/), { target: { value: 'tokyo' } });
      fireEvent.change(screen.getByLabelText(/延面積/), { target: { value: '100to150' } });
      fireEvent.change(screen.getByLabelText(/現在の状況/), { target: { value: 'price' } });
      fireEvent.change(screen.getByLabelText(/工事箇所/), { target: { value: 'wall' } });
      fireEvent.change(screen.getByLabelText(/携帯電話番号/), { target: { value: '08012345678' } });
      
      // フォームを送信
      fireEvent.click(screen.getByText('今すぐ相場を診断する'));
      
      // onSubmitが正しい値で呼ばれることを確認
      await waitFor(() => {
        expect(mockSubmit).toHaveBeenCalledWith({
          prefecture: 'tokyo',
          area: '100to150',
          situation: 'price',
          workType: 'wall',
          phone: '08012345678',
          email: undefined
        });
      });
    });
  });

  describe('HeroSection', () => {
    it('ヒーローセクションが正しくレンダリングされる', () => {
      const mockConsultClick = jest.fn();
      render(<HeroSection onConsultClick={mockConsultClick} />);
      
      expect(screen.getByText('おうちの塗装')).toBeInTheDocument();
      expect(screen.getByText('はもう悩まない。')).toBeInTheDocument();
      expect(screen.getByText('累計利用者数')).toBeInTheDocument();
      expect(screen.getByText('登録施工店')).toBeInTheDocument();
    });

    it('「今すぐ相談する」ボタンをクリックするとonConsultClickが呼ばれる', () => {
      const mockConsultClick = jest.fn();
      render(<HeroSection onConsultClick={mockConsultClick} />);
      
      fireEvent.click(screen.getByText('今すぐ相談する'));
      
      expect(mockConsultClick).toHaveBeenCalledTimes(1);
    });
  });

  describe('FAQSection', () => {
    it('FAQセクションが正しくレンダリングされる', () => {
      render(<FAQSection faqs={mockFaqs} />);
      
      expect(screen.getByText('よくある質問')).toBeInTheDocument();
      expect(screen.getByText('外壁塗装の窓口のよくある質問についてお答えします')).toBeInTheDocument();
      expect(screen.getByText('外壁塗装の窓口を利用するのに費用はかかりますか？')).toBeInTheDocument();
      expect(screen.getByText('外壁塗装の相場はどのくらいですか？')).toBeInTheDocument();
    });

    it('質問をクリックすると回答が表示される', () => {
      render(<FAQSection faqs={mockFaqs} />);
      
      // 最初は回答が表示されていないことを確認
      expect(screen.queryByText('外壁塗装の窓口のご利用は完全無料です。')).not.toBeVisible();
      
      // 質問をクリック
      fireEvent.click(screen.getByText('外壁塗装の窓口を利用するのに費用はかかりますか？'));
      
      // 回答が表示されることを確認
      expect(screen.getByText(/外壁塗装の窓口のご利用は/)).toBeVisible();
    });
  });
});
