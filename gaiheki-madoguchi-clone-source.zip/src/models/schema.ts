// src/models/schema.ts
import mongoose from 'mongoose';
import { User, Client, Article, Diagnosis, Contact, Review } from './types';

// ユーザースキーマ
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['admin', 'client', 'user'], default: 'user' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// 施工店スキーマ
const ClientSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  address: { type: String, required: true },
  prefecture: { type: String, required: true },
  city: { type: String, required: true },
  phone: { type: String, required: true },
  email: { type: String, required: true },
  website: { type: String },
  imageUrl: { type: String },
  rating: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// 記事スキーマ
const ArticleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  slug: { type: String, required: true, unique: true },
  imageUrl: { type: String },
  category: { type: String, required: true },
  tags: { type: [String], default: [] },
  authorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// 相場診断スキーマ
const DiagnosisSchema = new mongoose.Schema({
  prefecture: { type: String, required: true },
  area: { type: String, required: true },
  situation: { type: String, required: true },
  workType: { type: String, required: true },
  phone: { type: String, required: true },
  email: { type: String },
  status: { type: String, enum: ['pending', 'contacted', 'completed', 'cancelled'], default: 'pending' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// お問い合わせスキーマ
const ContactSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  message: { type: String, required: true },
  status: { type: String, enum: ['unread', 'read', 'replied', 'resolved'], default: 'unread' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// レビュースキーマ
const ReviewSchema = new mongoose.Schema({
  clientId: { type: mongoose.Schema.Types.ObjectId, ref: 'Client', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  comment: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// モデルの作成（既に存在する場合は再利用）
export const UserModel = mongoose.models.User || mongoose.model<User & mongoose.Document>('User', UserSchema);
export const ClientModel = mongoose.models.Client || mongoose.model<Client & mongoose.Document>('Client', ClientSchema);
export const ArticleModel = mongoose.models.Article || mongoose.model<Article & mongoose.Document>('Article', ArticleSchema);
export const DiagnosisModel = mongoose.models.Diagnosis || mongoose.model<Diagnosis & mongoose.Document>('Diagnosis', DiagnosisSchema);
export const ContactModel = mongoose.models.Contact || mongoose.model<Contact & mongoose.Document>('Contact', ContactSchema);
export const ReviewModel = mongoose.models.Review || mongoose.model<Review & mongoose.Document>('Review', ReviewSchema);
