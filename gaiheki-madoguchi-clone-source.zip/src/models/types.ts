// src/models/types.ts
export interface User {
  id: string;
  name: string;
  email: string;
  password: string; // ハッシュ化されたパスワード
  role: 'admin' | 'client' | 'user';
  createdAt: Date;
  updatedAt: Date;
}

export interface Client {
  id: string;
  name: string;
  description: string;
  address: string;
  prefecture: string;
  city: string;
  phone: string;
  email: string;
  website?: string;
  imageUrl?: string;
  rating: number;
  reviews?: Review[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Article {
  id: string;
  title: string;
  content: string;
  slug: string;
  imageUrl?: string;
  category: string;
  tags: string[];
  authorId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Diagnosis {
  id: string;
  prefecture: string;
  area: string;
  situation: string;
  workType: string;
  phone: string;
  email?: string;
  status: 'pending' | 'contacted' | 'completed' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

export interface Contact {
  id: string;
  name: string;
  email: string;
  phone?: string;
  message: string;
  status: 'unread' | 'read' | 'replied' | 'resolved';
  createdAt: Date;
  updatedAt: Date;
}

export interface Review {
  id: string;
  clientId: string;
  userId: string;
  rating: number;
  comment: string;
  createdAt: Date;
  updatedAt: Date;
}
