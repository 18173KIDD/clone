import { FC } from 'react';
import Head from 'next/head';
import Header from '../components/common/Header';
import Footer from '../components/common/Footer';
import HeroSection from '../components/sections/HeroSection';
import DiagnosisForm from '../components/forms/DiagnosisForm';
import AboutSection from '../components/sections/AboutSection';
import FeaturesSection from '../components/sections/FeaturesSection';
import AreaSearchSection from '../components/sections/AreaSearchSection';
import FlowSection from '../components/sections/FlowSection';
import FAQSection from '../components/sections/FAQSection';
import ArticlesSection from '../components/sections/ArticlesSection';
import CTASection from '../components/sections/CTASection';

// 仮のデータ
const prefectures = [
  { name: '北海道', slug: 'hokkaido' },
  { name: '東京都', slug: 'tokyo' },
  { name: '大阪府', slug: 'osaka' },
  { name: '愛知県', slug: 'aichi' },
  { name: '福岡県', slug: 'fukuoka' },
  // 他の都道府県
];

const faqs = [
  {
    question: '外壁塗装の窓口を利用するのに費用はかかりますか？',
    answer: '外壁塗装の窓口のご利用は<strong>完全無料</strong>です。相談料や紹介料などの費用は一切かかりません。'
  },
  {
    question: '外壁塗装の相場はどのくらいですか？',
    answer: '一般的な戸建て住宅（30坪程度）の外壁塗装の相場は、60〜90万円程度です。ただし、建物の状態や使用する塗料、施工範囲などによって価格は変動します。詳しくは無料相場診断をご利用ください。'
  },
  {
    question: '外壁塗装はどのくらいの頻度で行うべきですか？',
    answer: '外壁塗装の耐用年数は使用する塗料や環境によって異なりますが、一般的には10〜15年程度です。定期的なメンテナンスを行うことで、建物の寿命を延ばすことができます。'
  },
  // 他のFAQ
];

const articles = [
  {
    id: '1',
    title: '【2025年版】外壁塗装の助成金・補助金まとめ｜申請方法・条件や注意点を解説',
    slug: 'subsidy-guide-2025',
    imageUrl: '/images/article-sample.jpg',
    category: 'subsidy'
  },
  {
    id: '2',
    title: '【2025年版】外壁塗装の費用相場はいくら？10坪〜100坪の適正価格と安く抑えるコツ',
    slug: 'price-guide-2025',
    imageUrl: '/images/article-sample.jpg',
    category: 'price'
  },
  // 他の記事
];

const HomePage: FC = () => {
  const handleDiagnosisSubmit = (data: any) => {
    console.log('診断フォーム送信:', data);
    // APIリクエストを送信する処理を実装予定
  };

  const handleConsultClick = () => {
    // 相談フォームへスクロールする処理
    const element = document.getElementById('diagnosis-form');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="l-page">
      <Head>
        <title>外壁塗装の窓口|日本最大級の一括見積もりサイトが優良外壁塗装業者を紹介</title>
        <meta name="description" content="外壁塗装の窓口は、全国の優良リフォーム会社、塗装専門会社とのネットワークを持ち、独立した第三者機関の立場からお客様のご要望やご希望に沿った会社をご案内しています。" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Header />

      <main className="l-main">
        <HeroSection onConsultClick={handleConsultClick} />
        
        <div id="diagnosis-form" className="l-section">
          <DiagnosisForm onSubmit={handleDiagnosisSubmit} />
        </div>
        
        <AboutSection />
        <FeaturesSection />
        <AreaSearchSection prefectures={prefectures} />
        <FlowSection />
        <FAQSection faqs={faqs} />
        <ArticlesSection articles={articles} />
        <CTASection />
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;
