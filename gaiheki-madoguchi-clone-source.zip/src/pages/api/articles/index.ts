import { NextApiRequest, NextApiResponse } from 'next';

// 記事データの型
interface Article {
  id: string;
  title: string;
  content: string;
  slug: string;
  imageUrl?: string;
  category: string;
  tags: string[];
  authorId: string;
  createdAt: string;
  updatedAt: string;
}

// 仮の記事データ
const mockArticles: Article[] = [
  {
    id: '1',
    title: '【2025年版】外壁塗装の助成金・補助金まとめ｜申請方法・条件や注意点を解説',
    content: '外壁塗装の助成金・補助金に関する詳細な記事内容...',
    slug: 'subsidy-guide-2025',
    imageUrl: '/images/article-sample1.jpg',
    category: 'subsidy',
    tags: ['助成金', '補助金', '申請方法'],
    authorId: '1',
    createdAt: '2025-01-15T00:00:00Z',
    updatedAt: '2025-01-15T00:00:00Z'
  },
  {
    id: '2',
    title: '【2025年版】外壁塗装の費用相場はいくら？10坪〜100坪の適正価格と安く抑えるコツ',
    content: '外壁塗装の費用相場に関する詳細な記事内容...',
    slug: 'price-guide-2025',
    imageUrl: '/images/article-sample2.jpg',
    category: 'price',
    tags: ['費用相場', '適正価格', '節約方法'],
    authorId: '2',
    createdAt: '2025-02-10T00:00:00Z',
    updatedAt: '2025-02-10T00:00:00Z'
  },
  // 他の記事データ
];

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // GETリクエストのみを許可
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    // クエリパラメータからカテゴリを取得
    const { category } = req.query;

    // カテゴリでフィルタリング（指定がない場合は全件取得）
    let filteredArticles = mockArticles;
    if (category && typeof category === 'string') {
      filteredArticles = mockArticles.filter(article => article.category === category);
    }

    // TODO: 実際のデータベースからデータを取得する処理
    // const articles = await getArticlesFromDatabase(category);

    // 成功レスポンス
    return res.status(200).json({ 
      success: true,
      articles: filteredArticles
    });
  } catch (error) {
    console.error('記事一覧取得エラー:', error);
    return res.status(500).json({ message: 'サーバーエラーが発生しました' });
  }
}
