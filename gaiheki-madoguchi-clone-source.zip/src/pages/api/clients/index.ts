import { NextApiRequest, NextApiResponse } from 'next';

// 施工店データの型
interface Client {
  id: string;
  name: string;
  description: string;
  address: string;
  prefecture: string;
  city: string;
  phone: string;
  email: string;
  website?: string;
  imageUrl?: string;
  rating: number;
}

// 仮の施工店データ
const mockClients: Client[] = [
  {
    id: '1',
    name: '株式会社外壁塗装プロ',
    description: '創業20年の実績。外壁塗装のプロフェッショナル集団です。',
    address: '東京都新宿区西新宿1-1-1',
    prefecture: 'tokyo',
    city: '新宿区',
    phone: '03-1234-5678',
    email: 'info@gaiheki-pro.example.com',
    website: 'https://gaiheki-pro.example.com',
    imageUrl: '/images/client-sample1.jpg',
    rating: 4.8
  },
  {
    id: '2',
    name: '株式会社匠塗装',
    description: '職人の技術にこだわる塗装専門会社です。',
    address: '大阪府大阪市北区梅田2-2-2',
    prefecture: 'osaka',
    city: '大阪市北区',
    phone: '06-1234-5678',
    email: 'info@takumi-paint.example.com',
    website: 'https://takumi-paint.example.com',
    imageUrl: '/images/client-sample2.jpg',
    rating: 4.7
  },
  // 他の施工店データ
];

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // GETリクエストのみを許可
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    // クエリパラメータから都道府県を取得
    const { prefecture } = req.query;

    // 都道府県でフィルタリング（指定がない場合は全件取得）
    let filteredClients = mockClients;
    if (prefecture && typeof prefecture === 'string') {
      filteredClients = mockClients.filter(client => client.prefecture === prefecture);
    }

    // TODO: 実際のデータベースからデータを取得する処理
    // const clients = await getClientsFromDatabase(prefecture);

    // 成功レスポンス
    return res.status(200).json({ 
      success: true,
      clients: filteredClients
    });
  } catch (error) {
    console.error('施工店一覧取得エラー:', error);
    return res.status(500).json({ message: 'サーバーエラーが発生しました' });
  }
}
