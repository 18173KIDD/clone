import { NextApiRequest, NextApiResponse } from 'next';

// お問い合わせデータの型
interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  message: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // POSTリクエストのみを許可
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    const data = req.body as ContactFormData;

    // バリデーション
    if (!data.name || !data.email || !data.message) {
      return res.status(400).json({ message: '必須項目が入力されていません' });
    }

    // メールアドレスの形式チェック
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      return res.status(400).json({ message: 'メールアドレスの形式が正しくありません' });
    }

    // 電話番号の形式チェック（入力されている場合）
    if (data.phone) {
      const phoneRegex = /^[0-9]{10,11}$/;
      if (!phoneRegex.test(data.phone)) {
        return res.status(400).json({ message: '電話番号の形式が正しくありません' });
      }
    }

    // TODO: データベースに保存する処理
    // const result = await saveContactToDatabase(data);

    // TODO: メール通知を送信する処理
    // await sendContactNotificationEmail(data);

    // 成功レスポンス
    return res.status(200).json({ 
      success: true, 
      message: 'お問い合わせが送信されました'
    });
  } catch (error) {
    console.error('お問い合わせフォーム処理エラー:', error);
    return res.status(500).json({ message: 'サーバーエラーが発生しました' });
  }
}
