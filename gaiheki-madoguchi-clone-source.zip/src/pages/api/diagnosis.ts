import { NextApiRequest, NextApiResponse } from 'next';

// 相場診断フォームのデータ型
interface DiagnosisFormData {
  prefecture: string;
  area: string;
  situation: string;
  workType: string;
  phone: string;
  email?: string;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // POSTリクエストのみを許可
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    const data = req.body as DiagnosisFormData;

    // バリデーション
    if (!data.prefecture || !data.area || !data.situation || !data.workType || !data.phone) {
      return res.status(400).json({ message: '必須項目が入力されていません' });
    }

    // 電話番号の形式チェック
    const phoneRegex = /^[0-9]{10,11}$/;
    if (!phoneRegex.test(data.phone)) {
      return res.status(400).json({ message: '電話番号の形式が正しくありません' });
    }

    // メールアドレスの形式チェック（入力されている場合）
    if (data.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        return res.status(400).json({ message: 'メールアドレスの形式が正しくありません' });
      }
    }

    // TODO: データベースに保存する処理
    // const result = await saveDiagnosisToDatabase(data);

    // TODO: メール通知を送信する処理
    // await sendNotificationEmail(data);

    // 成功レスポンス
    return res.status(200).json({ 
      success: true, 
      message: '相場診断フォームが送信されました',
      // 仮の相場診断結果
      result: {
        estimatedPrice: {
          min: 600000,
          max: 900000
        },
        recommendedPaint: 'シリコン塗料',
        estimatedDuration: '2週間〜3週間',
        nextStep: 'アドバイザーからお電話でご連絡いたします'
      }
    });
  } catch (error) {
    console.error('相場診断フォーム処理エラー:', error);
    return res.status(500).json({ message: 'サーバーエラーが発生しました' });
  }
}
