import { NextApiRequest, NextApiResponse } from 'next';
import NextAuth, { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';

// 認証オプションの設定
export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      // 認証プロバイダーの名前
      name: 'Credentials',
      // 認証情報の設定
      credentials: {
        email: { label: 'メールアドレス', type: 'email' },
        password: { label: 'パスワード', type: 'password' }
      },
      // 認証処理
      async authorize(credentials) {
        // 認証情報のチェック
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        try {
          // TODO: 実際のデータベースでユーザー認証を行う処理
          // const user = await authenticateUser(credentials.email, credentials.password);
          
          // 仮のユーザー認証（開発用）
          // 実際の実装では、データベースからユーザーを検索し、パスワードを検証する
          if (credentials.email === 'admin@example.com' && credentials.password === 'password123') {
            return {
              id: '1',
              name: '管理者',
              email: 'admin@example.com',
              role: 'admin'
            };
          }
          
          // 認証失敗
          return null;
        } catch (error) {
          console.error('認証エラー:', error);
          return null;
        }
      }
    })
  ],
  // セッション設定
  session: {
    strategy: 'jwt',
    maxAge: 30 * 24 * 60 * 60, // 30日
  },
  // JWT設定
  jwt: {
    secret: process.env.NEXTAUTH_SECRET,
  },
  // ページ設定
  pages: {
    signIn: '/auth/login',
    signOut: '/auth/logout',
    error: '/auth/error',
  },
  // コールバック
  callbacks: {
    // JWTコールバック
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
      }
      return token;
    },
    // セッションコールバック
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string;
        session.user.role = token.role as string;
      }
      return session;
    }
  }
};

// NextAuth関数をエクスポート
export default NextAuth(authOptions);
