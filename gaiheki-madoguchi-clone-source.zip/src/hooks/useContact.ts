// src/hooks/useContact.ts
import { useState } from 'react';

interface ContactFormData {
  name: string;
  email: string;
  phone?: string;
  message: string;
}

export const useContact = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const submitContact = async (data: ContactFormData) => {
    setLoading(true);
    setError(null);
    setSuccess(false);
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      const responseData = await response.json();
      
      if (!response.ok) {
        throw new Error(responseData.message || 'お問い合わせの送信に失敗しました');
      }
      
      setSuccess(true);
      return responseData;
    } catch (err) {
      setError(err instanceof Error ? err.message : '予期せぬエラーが発生しました');
      return null;
    } finally {
      setLoading(false);
    }
  };
  
  return {
    submitContact,
    loading,
    error,
    success,
  };
};
