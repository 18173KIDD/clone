// src/hooks/useArticles.ts
import { useState, useEffect } from 'react';
import { Article } from '../models/types';

export const useArticles = (category?: string) => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchArticles = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const url = category 
          ? `/api/articles?category=${encodeURIComponent(category)}` 
          : '/api/articles';
          
        const response = await fetch(url);
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.message || '記事データの取得に失敗しました');
        }
        
        setArticles(data.articles);
      } catch (err) {
        setError(err instanceof Error ? err.message : '予期せぬエラーが発生しました');
      } finally {
        setLoading(false);
      }
    };
    
    fetchArticles();
  }, [category]);
  
  return {
    articles,
    loading,
    error,
  };
};
