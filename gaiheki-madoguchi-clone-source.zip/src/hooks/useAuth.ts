// src/hooks/useAuth.ts
import { useState, useEffect } from 'react';
import { signIn, signOut, useSession } from 'next-auth/react';

interface LoginCredentials {
  email: string;
  password: string;
}

export const useAuth = () => {
  const { data: session, status } = useSession();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const login = async ({ email, password }: LoginCredentials) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await signIn('credentials', {
        redirect: false,
        email,
        password,
      });
      
      if (result?.error) {
        throw new Error(result.error || 'ログインに失敗しました');
      }
      
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : '予期せぬエラーが発生しました');
      return false;
    } finally {
      setLoading(false);
    }
  };
  
  const logout = async () => {
    setLoading(true);
    
    try {
      await signOut({ redirect: false });
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : '予期せぬエラーが発生しました');
      return false;
    } finally {
      setLoading(false);
    }
  };
  
  return {
    login,
    logout,
    user: session?.user,
    isAuthenticated: !!session,
    isLoading: status === 'loading' || loading,
    error,
  };
};
