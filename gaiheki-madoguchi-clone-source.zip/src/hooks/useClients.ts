// src/hooks/useClients.ts
import { useState, useEffect } from 'react';
import { Client } from '../models/types';

export const useClients = (prefecture?: string) => {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchClients = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const url = prefecture 
          ? `/api/clients?prefecture=${encodeURIComponent(prefecture)}` 
          : '/api/clients';
          
        const response = await fetch(url);
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.message || '施工店データの取得に失敗しました');
        }
        
        setClients(data.clients);
      } catch (err) {
        setError(err instanceof Error ? err.message : '予期せぬエラーが発生しました');
      } finally {
        setLoading(false);
      }
    };
    
    fetchClients();
  }, [prefecture]);
  
  return {
    clients,
    loading,
    error,
  };
};
