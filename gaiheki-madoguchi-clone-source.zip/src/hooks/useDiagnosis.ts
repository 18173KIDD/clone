// src/hooks/useDiagnosis.ts
import { useState } from 'react';
import { DiagnosisFormData } from '../components/forms/DiagnosisForm';

export const useDiagnosis = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<any | null>(null);

  const submitDiagnosis = async (data: DiagnosisFormData) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/diagnosis', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      const responseData = await response.json();
      
      if (!response.ok) {
        throw new Error(responseData.message || '相場診断の送信に失敗しました');
      }
      
      setResult(responseData.result);
      return responseData;
    } catch (err) {
      setError(err instanceof Error ? err.message : '予期せぬエラーが発生しました');
      return null;
    } finally {
      setLoading(false);
    }
  };
  
  return {
    submitDiagnosis,
    loading,
    error,
    result,
  };
};
