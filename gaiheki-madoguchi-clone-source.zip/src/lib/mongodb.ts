import { MongoClient, Db } from 'mongodb';

// MongoDB接続URI
const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/gaiheki-madoguchi';

// グローバル変数
let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;

// MongoDB接続関数
export async function connectToDatabase(): Promise<{ client: MongoClient; db: Db }> {
  // キャッシュされたクライアントとデータベースがある場合は再利用
  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb };
  }

  // 環境変数のチェック
  if (!process.env.MONGODB_URI) {
    throw new Error('環境変数MONGODB_URIが設定されていません');
  }

  // MongoDBに接続
  const client = new MongoClient(uri);
  await client.connect();
  
  const db = client.db();

  // キャッシュに保存
  cachedClient = client;
  cachedDb = db;

  return { client, db };
}

// データモデル関数

// 相場診断データの保存
export async function saveDiagnosis(data: any) {
  const { db } = await connectToDatabase();
  return db.collection('diagnoses').insertOne({
    ...data,
    status: 'pending',
    createdAt: new Date(),
    updatedAt: new Date()
  });
}

// 施工店データの取得
export async function getClients(prefecture?: string) {
  const { db } = await connectToDatabase();
  const query = prefecture ? { prefecture } : {};
  return db.collection('clients').find(query).toArray();
}

// 記事データの取得
export async function getArticles(category?: string) {
  const { db } = await connectToDatabase();
  const query = category ? { category } : {};
  return db.collection('articles').find(query).toArray();
}

// お問い合わせデータの保存
export async function saveContact(data: any) {
  const { db } = await connectToDatabase();
  return db.collection('contacts').insertOne({
    ...data,
    status: 'unread',
    createdAt: new Date(),
    updatedAt: new Date()
  });
}

// ユーザー認証
export async function authenticateUser(email: string, password: string) {
  const { db } = await connectToDatabase();
  // 実際の実装では、パスワードのハッシュ比較などのセキュリティ対策が必要
  const user = await db.collection('users').findOne({ email });
  if (!user) return null;
  
  // TODO: パスワードの検証処理
  // const isValid = await verifyPassword(password, user.password);
  // if (!isValid) return null;
  
  return user;
}
